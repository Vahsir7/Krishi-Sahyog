# Smart-Agriculture-Ai
a multi-agent AI advisor for smart farming using your datasets and SQLite. The agents will work together to help farmers
